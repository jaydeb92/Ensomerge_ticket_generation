<?php

$username = "rajni";
$password = "rajni136@@";
$connection = new PDO( 'mysql:host=10.128.0.9;dbname=ticket', $username, $password );

	
?>
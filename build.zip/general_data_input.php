<?php
include 'config.php';
if (isset($_POST['submit']))
{
$ticketno = $conn -> real_escape_string($_POST['ticketno']);
$clientname =$conn -> real_escape_string( $_POST['clientname']);
$requeststatus = $conn -> real_escape_string($_POST['requeststatus']);
$reference = $conn -> real_escape_string($_POST['reference']);

$typeofbusiness = $conn -> real_escape_string($_POST['typeofbusiness']);

$discipline = $conn -> real_escape_string($_POST['discipline']);
$recruitmentstatus = $conn -> real_escape_string($_POST['recruitmentstatus']);


$requestupdates = $conn -> real_escape_string($_POST['requestupdates']);
$expectedtime = $conn -> real_escape_string($_POST['expectedtime']);

$initialresponse = $conn -> real_escape_string($_POST['initialresponse']);
$auoffshore = $conn -> real_escape_string($_POST['auoffshore']);
$emslaimpact = $conn -> real_escape_string($_POST['emslaimpact']);
$date = date("Y-m-d h:i:s");
$request_type = $conn -> real_escape_string($_POST['request_type']);
$emdocumentation = $conn -> real_escape_string($_POST['emdocumentation']);
//echo $emdocumentation;

 $query = ("INSERT INTO details(ticket_no,client_name,request_status,reference,type_of_business,discipline,request_update,expexted_time,initial_response_date,au_officer,em_sla_impact,request_on,recruitment_status,emdocumentation,request_type) VALUES ('$ticketno','$clientname','$requeststatus','$reference','$typeofbusiness','$discipline','$requestupdates','$expectedtime','$initialresponse','$auoffshore','$emslaimpact','$date','$recruitmentstatus','$emdocumentation','$request_type')");
  if (mysqli_multi_query($conn, $query)) {
        echo '<script type="text/javascript">';
        echo 'alert("Worksheet Details are added sucessfully");';
        echo 'window.location.href = "addnewticket.php";';
        echo '</script>';
    } else {
        echo '<script type="text/javascript">';
        echo 'alert("Worksheet Details are added Failed");';
        //echo 'window.location.href = "update1.php?id=$id";';
        echo 'window.location.href = "addnewticket.php";';
        echo '</script>';
    }
}
?>
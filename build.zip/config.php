<?php


$conn=mysqli_connect("10.128.0.9","rajni","rajni136@@","ticket");

?>